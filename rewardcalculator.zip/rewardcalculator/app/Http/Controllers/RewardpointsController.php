<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class RewardpointsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    //calculated reward points for the last 3 months
    public function calculator(Request $request)
    {
        try{
            $customerid = $request->route('customerid');
            $today = date('Y-m-d');
            $data=array();
            $sum=0;
            for($m=0;$m<=2;$m++)
            {
            $newdate = date('Y-m', strtotime('-'.$m.'  months', strtotime($today)));        

            $posts = DB::select("SELECT * FROM customer,customer_transaction where  customer.customerid=customer_transaction.customerid and customer.customerid='".$customerid."' and dateoftransaction like '".$newdate."%'");      
            $i=0;
            foreach ($posts as $p) {
                $customername=$p->customername;
                $i++;
                $amount=$p->amount;
                if($amount>100)
                $rewardpoints=(($amount-50)*1)+(($amount-100)*1);
                else if($amount>50)
                $rewardpoints=(($amount-50)*1);
                $sum=$sum+$rewardpoints;
                }
            $data['transaction'][]=array('year_month' =>$newdate,'rewardpoints' => $sum);
            }
        
            if($i==0)  
            {
                $data['message']="No records";
            return array('status'=>'failed','data'=>$data);
            }      
            else
            {
                $data['customername']=$customername;
                $data['totalsummarypoints']=$sum;             
            return array('status'=>'success','data'=>$data);
            }
        }catch (\Exception $e) {
            throw new HttpException(500, $e->getMessage());
        }
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
